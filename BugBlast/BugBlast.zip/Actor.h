#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameConstants.h"

class StudentWorld;
/****************************Actor******************************************************************/
class Actor: public GraphObject
{
public:
	//construtor
	Actor(StudentWorld* game, int id, int startX, int startY);//actor constructor will set visible
	//virtual destructor
	virtual ~Actor();
	virtual void doSomething();
	StudentWorld* getWorld();

private:
	StudentWorld* m_myWorld;
};


/****************************ActiveActor******************************************************************/
class ActiveActor :public Actor
{
public:
	ActiveActor(StudentWorld* game, int id, int startX, int startY);
	virtual bool isBlocked(int x,int y);//check for all kinds of brick, makes it virtual to specify type of brick in player class
	//if that position cannot be reached, return true, else(object that can be crossed, or nohing in that pos) return false

};



/****************Brick*************************************************************************/
class Brick: public Actor
{
public:
	//constructor
	Brick(StudentWorld* game,int startX, int startY);
};

class DeBrick: public Actor
{
public:
	DeBrick(StudentWorld* game,int startX, int startY);
};



/****************Player***********************************************************************/
class Player: public ActiveActor
{
public:
	//constructor
	Player(StudentWorld* game, int startX, int startY);
	virtual void doSomething();//overriding doSomething
	//setDead 
private:
};


#endif // ACTOR_H_
