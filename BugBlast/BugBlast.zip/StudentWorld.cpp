#include "StudentWorld.h"
#include "Actor.h"
#include "Level.h"
#include "GameConstants.h"
#include <sstream>  // defines the type std::ostringstream
#include <iomanip>  // defines the manipulator set
using namespace std;
GameWorld* createStudentWorld()
{
	return new StudentWorld();
}

StudentWorld::StudentWorld()
{
	vector<Actor*> m_actorsList;
}

StudentWorld::~StudentWorld()//???????????????????????????????
{
	for(unsigned int i=0;i<m_actorsList.size();i++)
		delete m_actorsList[i];
}


/***********helper function************************************/
void StudentWorld::updateDisplayText()
{
	//to be implemented
}

bool StudentWorld::playerDiedDuringThisTick()
{
	//to be changed
	return false;
}

Actor* StudentWorld::getActorAt(int x, int y)//return null if there is no match in container
{
	for(unsigned int i=0;i<m_actorsList.size();i++)
	{
		if(m_actorsList[i]->getX()==x && m_actorsList[i]->getY()==y )
			return m_actorsList[i];
	}
	return NULL;
}

string StudentWorld::getFileName(int level)
{
	ostringstream oss;
	oss.fill('0');
	oss<<setw(2)<<level;
	return "level"+oss.str()+".dat";
}
/************helper function*******************************/


int StudentWorld::init()
{
	Level lev;
	int currentLev=getLevel();
	Level::LoadResult result = lev.loadLevel(getFileName(currentLev));
	if (currentLev==0 && result == Level::load_fail_file_not_found)
		return GWSTATUS_NO_FIRST_LEVEL;
	else if(result == Level::load_fail_file_not_found)
		return GWSTATUS_PLAYER_WON;
	else if (result == Level::load_fail_bad_format)
		return GWSTATUS_LEVEL_ERROR;
	else if (result == Level::load_success)
	{
		int x,y,i=0;
		for(x=0;x<VIEW_WIDTH;x++)
		{
			for(y=0;y<VIEW_HEIGHT;y++)
			{
				Level::MazeEntry ge = lev.getContentsOf(x,y);
				switch (ge)
				{
				case Level::player:
					m_actorsList.push_back(new Player(this,x,y));
					break;
				case Level::perma_brick:
					m_actorsList.push_back(new Brick(this,x,y));
					break;
				case Level::destroyable_brick:
					m_actorsList.push_back(new DeBrick(this,x,y));
					break;
				}
			}
		}
		return GWSTATUS_CONTINUE_GAME;
	}
	else
		return GWSTATUS_LEVEL_ERROR;
}
int StudentWorld::move()
{
	updateDisplayText();
	for(unsigned int i=0;i<m_actorsList.size();i++)
	{
		if(m_actorsList[i]!=NULL)
		{
			m_actorsList[i]->doSomething();
			if(playerDiedDuringThisTick())
				return GWSTATUS_PLAYER_DIED;
		}
	}
	return GWSTATUS_CONTINUE_GAME;
}
void StudentWorld::cleanUp()
{
	for(unsigned int i=0;i<m_actorsList.size();i++)
		delete m_actorsList[i];
}