#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp
#include <vector>
#include <string>
using namespace std;
class Actor;
class StudentWorld : public GameWorld
{
public:
	StudentWorld();
	
	~StudentWorld();

	virtual int init();

	virtual int move();

	virtual void cleanUp();

	Actor* getActorAt(int x, int y);
	
	string getFileName(int level);
	void updateDisplayText();

	bool playerDiedDuringThisTick();

private:
	vector<Actor*> m_actorsList;
};

#endif // STUDENTWORLD_H_
