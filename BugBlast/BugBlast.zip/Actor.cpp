#include "Actor.h"
#include "StudentWorld.h"

/****************************Actor******************************************************************/
Actor::	Actor(StudentWorld* game, int id, int startX, int startY)
	: GraphObject(id, startX,startY), m_myWorld(game) 
{
	setVisible(true);
}

Actor::~Actor() {}

void Actor::doSomething() {}

StudentWorld* Actor::getWorld() 
{
	return m_myWorld;
}

/****************************ActiveActor******************************************************************/
ActiveActor::ActiveActor(StudentWorld* game, int id, int startX, int startY)
	:Actor(game, id,  startX,  startY)
{
}

bool ActiveActor::isBlocked(int x,int y)
{
	Actor* p=getWorld()->getActorAt(x,y);
	if(p!=NULL)
	{
		Brick* p1 = dynamic_cast<Brick*>(p);
		DeBrick* p2 = dynamic_cast<DeBrick*>(p);
		if (p1 != nullptr || p2!=nullptr)
			return true;
	}
	return false;
}


/****************Brick*************************************************************************/
Brick::Brick(StudentWorld* game,int startX, int startY) 
	: Actor(game,IID_PERMA_BRICK, startX,startY) 
{
}


DeBrick::DeBrick(StudentWorld* game,int startX, int startY)
	: Actor(game,IID_DESTROYABLE_BRICK, startX,startY) 
{	
}



/****************Player***********************************************************************/
Player::Player(StudentWorld* game, int startX, int startY) 
	: ActiveActor(game,IID_PLAYER, startX,startY) 
{
}


void Player::doSomething()
	{
		int ch;
		if(getWorld()->getKey(ch))
		{
			if(ch==KEY_PRESS_DOWN && !isBlocked(getX(), getY()-1))
				moveTo(getX(), getY()-1);
			if(ch==KEY_PRESS_LEFT &&!isBlocked(getX()-1, getY()))
				moveTo(getX()-1, getY());
			if(ch==KEY_PRESS_RIGHT && !isBlocked(getX()+1, getY()))
				moveTo(getX()+1, getY());
			if(ch==KEY_PRESS_UP && !isBlocked(getX(), getY()+1))
				moveTo(getX(), getY()+1);
			if(ch==KEY_PRESS_SPACE)
					return;//to be done
		}
	}